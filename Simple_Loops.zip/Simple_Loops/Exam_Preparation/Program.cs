﻿namespace Exam_Preparation
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}